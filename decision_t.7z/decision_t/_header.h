#pragma once
#include <fstream>
#include <map>
#include <math.h>
#include <float.h>
#include <cstdlib>
#include <iomanip>
#include <unordered_map>
using namespace std;
using vs=vector<string>;
using vvs=vector <vs>;
using  vi = vector<int>;
using msi=unordered_map<string, int>;
using vd=vector<double>;