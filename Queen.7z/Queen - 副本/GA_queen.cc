#ifndef __GA_QUEEN__
#include<vector>

#endif __GA_QUEEN__